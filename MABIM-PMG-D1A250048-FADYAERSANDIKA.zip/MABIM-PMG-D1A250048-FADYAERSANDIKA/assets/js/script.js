function togglePassword() {
  const pass = document.getElementById("password");
  const icon = document.querySelector(".toggle-password");

  if (pass.type === "password") {
    pass.type = "text";
    icon.classList.remove("fa-eye");
    icon.classList.add("fa-eye-slash");
  } else {
    pass.type = "password";
    icon.classList.remove("fa-eye-slash");
    icon.classList.add("fa-eye");
  }
}

function validasi() {
  let user = document.getElementById("username").value;
  let pass = document.getElementById("password").value;
  let error = document.getElementById("errorMsg");

  if (user === "" || pass === "") {
    error.style.display = "block";
    error.innerText = "Username/email dan password wajib diisi!";
    return false;
  }
  if (pass.length < 5) {
    error.style.display = "block";
    error.innerText = "Password minimal 5 karakter!";
    return false;
  }

  return true;
}