<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: index.php");
    exit;
}
echo "Selamat Berhasil Login<br>";
echo $_SESSION['session_username'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Fadya</title>
    <style>
        :root {
            --bg-dark: #0f172a;
            --bg-card: #1e293b;
            --text-main: #f1f5f9;
            --text-muted: #94a3b8;
            --accent: #6366f1;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', sans-serif; }

        body {
            background-color: var(--bg-dark);
            color: var(--text-main);
            display: flex;
            min-height: 100vh;
        }

        /* SIDEBAR */
        .sidebar {
            width: 260px;
            background-color: var(--bg-card);
            border-right: 1px solid #334155;
            display: flex;
            flex-direction: column;
            padding: 20px;
            position: fixed;
            height: 100%;
            top: 0; left: 0;
            z-index: 100;
        }

        .brand {
            font-size: 1.4rem;
            font-weight: 800;
            color: var(--accent);
            margin-bottom: 40px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .nav-links button {
            display: block;
            width: 100%;
            text-align: left;
            padding: 12px 15px;
            color: var(--text-muted);
            background: none;
            border: none;
            border-radius: 8px;
            margin-bottom: 5px;
            transition: 0.3s;
            font-weight: 500;
            cursor: pointer;
            font-size: 1rem;
        }

        .nav-links button:hover, .nav-links button.active {
            background-color: rgba(99, 102, 241, 0.1);
            color: var(--accent);
        }

        /* LOGOUT BUTTON STYLE */
        .btn-logout {
            margin-top: auto; /* Push to bottom */
            background-color: rgba(239, 68, 68, 0.1) !important;
            color: var(--danger) !important;
        }
        .btn-logout:hover {
            background-color: var(--danger) !important;
            color: white !important;
        }

        /* MAIN CONTENT */
        .main-content {
            margin-left: 260px;
            padding: 30px;
            width: 100%;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        .greeting h1 { font-size: 1.8rem; }
        
        .date-display { 
            background: var(--bg-card); 
            padding: 8px 20px; 
            border-radius: 50px; 
            border: 1px solid #334155;
            font-weight: bold;
            color: var(--accent);
            font-size: 0.9rem;
        }

        /* GRID & CARDS */
        .grid-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .card {
            background: var(--bg-card);
            padding: 20px;
            border-radius: 12px;
            border: 1px solid #334155;
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #334155;
        }
        
        .stat-value { font-size: 2rem; font-weight: 700; margin-bottom: 5px; }
        .stat-label { color: var(--text-muted); font-size: 0.9rem; }
        .text-accent { color: var(--accent); }
        .text-success { color: var(--success); }

        /* TABS LOGIC */
        .page-section { display: none; animation: fadeIn 0.3s ease; }
        .page-section.active-section { display: block; }

        /* LIST ITEMS */
        .list-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #334155;
        }
        .list-item:last-child { border-bottom: none; }
        
        .badge { padding: 4px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: bold; }
        .badge-live { background: rgba(16, 185, 129, 0.2); color: var(--success); }
        .badge-dev { background: rgba(245, 158, 11, 0.2); color: var(--warning); }

        /* TODO INPUT */
        .input-group { display: flex; gap: 10px; margin-bottom: 15px; }
        input[type="text"] {
            flex: 1; padding: 10px; border-radius: 6px; border: 1px solid #475569;
            background: var(--bg-dark); color: white; outline: none;
        }
        button.btn-action {
            padding: 0 15px; background: var(--accent); color: white;
            border: none; border-radius: 6px; cursor: pointer;
        }
        
        ul#todo-list { list-style: none; }
        ul#todo-list li {
            background: var(--bg-dark); padding: 10px; margin-bottom: 5px;
            border-radius: 6px; display: flex; justify-content: space-between; align-items: center;
        }
        .delete-btn { color: var(--danger); cursor: pointer; padding: 5px; }
        
        @keyframes fadeIn { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }

        @media (max-width: 768px) {
            .sidebar { display: none; }
            .main-content { margin-left: 0; padding: 20px; }
        }
    </style>
</head>
<body>

    <nav class="sidebar">
        <div class="brand">
            <span>⚡ Fadya Dev</span>
        </div>
        <div class="nav-links">
            <button onclick="switchTab('dashboard')" class="nav-btn active" id="btn-dashboard">Dashboard</button>
            <button onclick="switchTab('games')" class="nav-btn" id="btn-games">Games</button>
            <button onclick="switchTab('scripts')" class="nav-btn" id="btn-scripts">Scripts</button>
            <button onclick="switchTab('models')" class="nav-btn" id="btn-models">Assets</button>
            
            <button onclick="window.location.href='login.php'" class="nav-btn btn-logout">Logout</button>
        </div>
    </nav>

    <main class="main-content">
        
        <header>
            <div class="greeting">
                <h1 id="page-title">Dashboard</h1>
            </div>
            <div class="date-display" id="clock">00:00</div>
        </header>

        <div id="view-dashboard" class="page-section active-section">
            <div class="grid-container">
                <div class="card">
                    <div class="stat-value text-accent">12.5k</div>
                    <div class="stat-label">Total Visits</div>
                </div>
                <div class="card">
                    <div class="stat-value text-success">85%</div>
                    <div class="stat-label">Progress</div>
                </div>
                <div class="card">
                    <div class="stat-value" style="color: var(--warning);">3</div>
                    <div class="stat-label">Bugs</div>
                </div>
            </div>

            <div class="grid-container">
                <div class="card">
                    <div class="card-header"><h3>Projects</h3></div>
                    <div class="list-item">
                        <span>Mt. Canggah</span> <span class="badge badge-live">LIVE</span>
                    </div>
                    <div class="list-item">
                        <span>Horror Map</span> <span class="badge badge-dev">DEV</span>
                    </div>
                    <div class="list-item">
                        <span>Web Portfolio</span> <span class="badge badge-dev">DEV</span>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header"><h3>Tasks</h3></div>
                    <div class="input-group">
                        <input type="text" id="todo-input" placeholder="Add task...">
                        <button class="btn-action" onclick="addTodo()">+</button>
                    </div>
                    <ul id="todo-list"></ul>
                </div>
            </div>
        </div>

        <div id="view-games" class="page-section">
            <div class="grid-container">
                <div class="card">
                    <div class="card-header"><h3>Mt. Canggah</h3> <span class="badge badge-live">LIVE</span></div>
                    <button class="btn-action" style="width:100%">Manage</button>
                </div>
                <div class="card">
                    <div class="card-header"><h3>Horror Map</h3> <span class="badge badge-dev">DEV</span></div>
                    <button class="btn-action" style="width:100%; background: var(--warning);">Studio</button>
                </div>
            </div>
        </div>

        <div id="view-scripts" class="page-section">
             <div class="card">
                <div class="list-item">
                    <span>Cooking_System.lua</span> <span class="text-accent">Edit</span>
                </div>
                <div class="list-item">
                    <span>DataStore.lua</span> <span class="text-accent">Edit</span>
                </div>
                <div class="list-item">
                    <span>Movement.lua</span> <span class="text-accent">Edit</span>
                </div>
             </div>
        </div>

        <div id="view-models" class="page-section">
             <div class="card">
                <div class="grid-container" style="margin-bottom:0;">
                    <div style="background:var(--bg-dark); padding:20px; border-radius:8px; text-align:center;">Sate Model</div>
                    <div style="background:var(--bg-dark); padding:20px; border-radius:8px; text-align:center;">Knife Tool</div>
                    <div style="background:var(--bg-dark); padding:20px; border-radius:8px; text-align:center;">Tree Asset</div>
                </div>
             </div>
        </div>

    </main>

    <script>
        // TAB SWITCHER
        function switchTab(tabName) {
            document.querySelectorAll('.page-section').forEach(sec => sec.classList.remove('active-section'));
            const target = document.getElementById('view-' + tabName);
            if(target) target.classList.add('active-section');

            document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
            const btn = document.getElementById('btn-' + tabName);
            if(btn) btn.classList.add('active');

            const titles = { 'dashboard': 'Dashboard', 'games': 'My Games', 'scripts': 'Lua Scripts', 'models': 'Assets' };
            document.getElementById('page-title').innerText = titles[tabName] || 'Dashboard';
        }

        // CLOCK
        function updateClock() {
            const now = new Date();
            document.getElementById('clock').innerText = now.toLocaleString('id-ID', { weekday: 'short', hour: '2-digit', minute: '2-digit' });
        }
        setInterval(updateClock, 1000);
        updateClock();

        // TODO LIST
        const todoInput = document.getElementById('todo-input');
        const todoList = document.getElementById('todo-list');
        let todos = JSON.parse(localStorage.getItem('fadyaTodosClean')) || ["Fix bug map"];

        function renderTodos() {
            todoList.innerHTML = "";
            todos.forEach((todo, index) => {
                todoList.innerHTML += `<li><span>${todo}</span><span class="delete-btn" onclick="deleteTodo(${index})">×</span></li>`;
            });
        }
        function addTodo() {
            if (todoInput.value.trim()) { todos.unshift(todoInput.value.trim()); save(); todoInput.value = ""; }
        }
        function deleteTodo(index) { todos.splice(index, 1); save(); }
        function save() { localStorage.setItem('fadyaTodosClean', JSON.stringify(todos)); renderTodos(); }
        renderTodos();
    </script>

</body>
</html>