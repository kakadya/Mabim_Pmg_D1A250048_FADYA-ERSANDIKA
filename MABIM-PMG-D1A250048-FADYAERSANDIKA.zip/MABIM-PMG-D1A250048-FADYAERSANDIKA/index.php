<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- ini Judul -->
    <title>Mabim Fasilkom 2026</title>
    <link rel="icon" href="assets/img/icon.png" />
    <link
  rel="stylesheet"
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
/>
    <link rel="stylesheet" href="assets/css/style.css" />
  </head>
  <body style=" backdrop-filter: blur(5px); background-image: url('assets/img/teknologi.jpg'); background-size: cover; background-position: center;">
    <!-- <h1>hello world</h1>
    <h2></h2> -->
    <div class="login-class" style="background-color:blue;outline: 2px solid white;">
      <h2 style="color:white" class="judul-login">LOGIN</h2>
      <form action="login.php" method="post">
        <label style="color:white;">USERNAME</label>
        <input type="text" name="username" id="username" style="outline: 2px solid black;"/>
        <label style="color:white;">PASSWORD</label>
<div class="password-wrapper">
  <input type="password" name="password" id="password" style="outline: 2px solid black;" />
  <i class="fa-solid fa-eye toggle-password" onclick="togglePassword()"></i>
</div>
        
        <div class="error" id="errorMsg"></div>

        <input type="submit"  class="login-button" value="LOGIN"/>
      </form>
    </div>
    <script src="assets/js/script.js"></script>
  </body>
</html>